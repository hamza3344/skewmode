﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skewnessmode
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> mylist = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                mylist.Add(double.Parse(s));
            }
            double mode = mylist.GroupBy(v => v).OrderByDescending(g => g.Count())
                .Select(gr => gr.Key).First();
            double mean = mylist.Average();
            double stdmean = Math.Sqrt(mylist.Sum(x => Math.Pow(x - mylist.Average(), 2)) / mylist.Count());
            double skewmode = (mean - mode) / stdmean;
            MessageBox.Show(skewmode + "");
        }
    }
}
